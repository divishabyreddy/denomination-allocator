﻿using System;
using System.Collections.Generic;

namespace DenominationAllocator
{
    public class Allocator
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Please enter amount and price of the product in £");
            Console.WriteLine();

            var (amount, price) = GetAmountAndProductPrice();

            if (amount == price)
                Console.WriteLine("Your change is £0");
            else
                GetRemainingAmountDenominations(amount - price);

            Console.ReadKey();
        }

        /// <summary>
        /// Splits the remaining amount into denominations and writes it to the console
        /// </summary>
        /// <param name="remainingAmount"></param>
        private static void GetRemainingAmountDenominations(decimal remainingAmount)
        {
            var denominations = new Dictionary<int, string>
            {
                { 5000, "£50"},
                { 2000, "£20"},
                { 1000, "£10"},
                { 500, "£5"},
                { 200, "£2"},
                { 100, "£1"},
                { 50, "50p"},
                { 20, "20p"},
                { 10, "10p"},
                { 5, "5p"},
                { 2, "2p"},
                { 1, "1p"}
            };


            remainingAmount = remainingAmount * 100;
            Console.WriteLine("Your change is:");
            foreach (var den in denominations)
            {
                if(remainingAmount >= den.Key)
                {
                    var count = (int)((remainingAmount) / den.Key);
                    Console.WriteLine(string.Concat(count.ToString(), "x ", den.Value));
                    remainingAmount -= count*den.Key;
                }
            }
            
        }

        /// <summary>
        /// Takes the amount and price as input and returns the values
        /// </summary>
        /// <returns></returns>
        private static (decimal amount, decimal productPrice) GetAmountAndProductPrice()
        {
            decimal amount;
            decimal productPrice;


            while (true)
            {
                Console.Write("Amount: £");
                if (decimal.TryParse(Console.ReadLine(), out amount) && amount > 0)
                    break;

                //Assuming that price is never zero
                Console.WriteLine("Amount must be positive");

            }


            while (true)
            {
                Console.Write("Product Price: £");
                if (decimal.TryParse(Console.ReadLine(), out productPrice) 
                    && productPrice > 0
                    && productPrice <= amount)
                    break;

                Console.WriteLine("Product price must be positive and should be less than or equal to amount");
            }

            return (amount, productPrice);
        }

        
    }
}
