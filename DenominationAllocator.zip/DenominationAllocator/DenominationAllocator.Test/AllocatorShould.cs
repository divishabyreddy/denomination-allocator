﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;
using DenominationAllocator;
using System.Text;

namespace DenominationAllocator.Test
{
    [TestClass]
    public class AllocatorShould
    {
        private StringWriter sw;
        private StringReader sr;

        [TestInitialize]
        public void Init() 
        { 
            sw = new StringWriter();

            Console.SetOut(sw);
        }

        [TestCleanup]
        public void Cleanup()
        {
            sw.Dispose();
            sr?.Dispose();
        }

        [TestMethod]
        public void VerifyDenominationsAllocator()
        {
            string amount = "5";
            string price = "2";

            StringBuilder stringToRead = new StringBuilder();
            stringToRead.AppendLine(amount);
            stringToRead.AppendLine(price);

            sr = new StringReader(stringToRead.ToString());
            Console.SetIn(sr);
            Allocator.Main(new[] {""} );

            string output = sw.ToString();
            Assert.IsTrue(output.Contains("1x £2\r\n1x £1"));
        }

        [TestMethod]
        public void VerifyIfAmountAndPriceAreValidated()
        {
            string invalidAmount = "-1";
            string amount = "5";
            string invalidPrice = "-1";
            string price = "2";

            StringBuilder stringToRead = new StringBuilder();
            stringToRead.AppendLine(invalidAmount);
            stringToRead.AppendLine(amount);
            stringToRead.AppendLine(invalidPrice);
            stringToRead.AppendLine(price);

            sr = new StringReader(stringToRead.ToString());
            Console.SetIn(sr);
            Allocator.Main(new[] { "" });

            string output = sw.ToString();
            Assert.IsTrue(output.Contains("Amount must be positive"));
            Assert.IsTrue(output.Contains("Product price must be positive and should be less than or equal to amount"));
            Assert.IsTrue(output.Contains("1x £2\r\n1x £1"));
        }

        [TestMethod]
        public void CheckOutputWhenAmountAndPriceAreEqual()
        {
            string amount = "5";
            string price = "5";

            StringBuilder stringToRead = new StringBuilder();
            stringToRead.AppendLine(amount);
            stringToRead.AppendLine(price);

            sr = new StringReader(stringToRead.ToString());
            Console.SetIn(sr);
            Allocator.Main(new[] { "" });

            string output = sw.ToString();
            Assert.IsTrue(output.Contains("Your change is £0"));
        }

        [TestMethod]
        public void VerifyIfAmountAndPriceAreValidatedForInvalidInput()
        {
            string invalidAmount = "xxx";
            string amount = "5";
            string price = "2";

            StringBuilder stringToRead = new StringBuilder();
            stringToRead.AppendLine(invalidAmount);
            stringToRead.AppendLine(amount);
            stringToRead.AppendLine(price);

            sr = new StringReader(stringToRead.ToString());
            Console.SetIn(sr);
            Allocator.Main(new[] { "" });

            string output = sw.ToString();
            Assert.IsTrue(output.Contains("Amount must be positive"));
            Assert.IsTrue(output.Contains("1x £2\r\n1x £1"));
        }
    }
}
